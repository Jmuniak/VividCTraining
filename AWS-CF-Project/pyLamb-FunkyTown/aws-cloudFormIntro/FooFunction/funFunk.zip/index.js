'use strict'

exports.handler = function(event, context) {
    console.log('hi foo');
}

